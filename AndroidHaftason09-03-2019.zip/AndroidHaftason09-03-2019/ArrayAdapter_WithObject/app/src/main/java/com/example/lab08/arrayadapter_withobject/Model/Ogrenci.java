package com.example.lab08.arrayadapter_withobject.Model;

public class Ogrenci {
    private String OrenciAdi;
    private String OrenciSoyaAdi;
    private String OrenciBolm;
    private String OrenciEmail;
    public Ogrenci() {

    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "OrenciAdi='" + OrenciAdi + '\'' +
                ", OrenciSoyaAdi='" + OrenciSoyaAdi + '\'' +
                ", OrenciBolm='" + OrenciBolm + '\'' +
                ", OrenciEmail='" + OrenciEmail + '\'' +
                '}';
    }

    public Ogrenci(String orenciAdi, String orenciSoyaAdi, String orenciBolm, String orenciEmail) {
        OrenciAdi = orenciAdi;
        OrenciSoyaAdi = orenciSoyaAdi;
        OrenciBolm = orenciBolm;
        OrenciEmail = orenciEmail;
    }

    public String getOrenciAdi() {
        return OrenciAdi;
    }

    public void setOrenciAdi(String orenciAdi) {
        OrenciAdi = orenciAdi;
    }

    public String getOrenciSoyaAdi() {
        return OrenciSoyaAdi;
    }

    public void setOrenciSoyaAdi(String orenciSoyaAdi) {
        OrenciSoyaAdi = orenciSoyaAdi;
    }

    public String getOrenciBolm() {
        return OrenciBolm;
    }

    public void setOrenciBolm(String orenciBolm) {
        OrenciBolm = orenciBolm;
    }

    public String getOrenciEmail() {
        return OrenciEmail;
    }

    public void setOrenciEmail(String orenciEmail) {
        OrenciEmail = orenciEmail;
    }



}
