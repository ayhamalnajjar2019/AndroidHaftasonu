package com.ismek.ogrenci.satisuygulama.Model;

public class CKategori
{
    public int Kod;
    public String Baslik;
    public String Resim;

    public CKategori()
    {
    }

    public CKategori(int kod, String baslik, String resim)
    {
        Kod = kod;
        Baslik = baslik;
        Resim = resim;
    }

    public int getKod() {
        return Kod;
    }

    public void setKod(int kod) {
        Kod = kod;
    }

    public String getBaslik() {
        return Baslik;
    }

    public void setBaslik(String baslik) {
        Baslik = baslik;
    }

    public String getResim() {
        return Resim;
    }

    public void setResim(String resim) {
        Resim = resim;
    }
}

