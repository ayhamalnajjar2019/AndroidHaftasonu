package com.ismek.ogrenci.satisuygulama.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.ismek.ogrenci.satisuygulama.Adapter.AdpterAltKategori;
import com.ismek.ogrenci.satisuygulama.Model.AltKategori;
import com.ismek.ogrenci.satisuygulama.Model.CKategori;
import com.ismek.ogrenci.satisuygulama.R;

import java.util.ArrayList;

public class AltActivity extends AppCompatActivity {
ListView altKategori;
ArrayList<AltKategori> altkategoriler;
AdpterAltKategori  adpterAltKategori ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt);

        CKategori kategori= (CKategori)getIntent().getSerializableExtra("Kategori");
        this.setTitle(kategori.getBaslik());

        altKategori = findViewById(R.id.AltKategoriListe);
        altkategoriler = new ArrayList<>();
        if(kategori.getKod()==1)
        {
            altkategoriler.add(new AltKategori(1,1,"masaustu bilgisyar",
                    "","masaustu bilgisyar"));
            altkategoriler.add(new AltKategori(1,1,"Dizustu bilgisyar",
                    "","Dizustu bilgisyar"));
            altkategoriler.add(new AltKategori(1,1,"HDD/SSD",
                    "","HDD/SSD"));
        }
        else if(kategori.getKod()==2)
        {
            altkategoriler.add(new AltKategori(1,1,"T-shirt",
                    "","T-shirt big sadas"));
            altkategoriler.add(new AltKategori(1,1,"kazak",
                    "","kazak dsfsdfsdfsd"));
            altkategoriler.add(new AltKategori(1,1,"pantolon",
                    "","pantolon asdas zzs "));
        }
        adpterAltKategori = new AdpterAltKategori(altkategoriler,getApplicationContext());
    }
}
