package com.ismek.ogrenci.satisuygulama.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ismek.ogrenci.satisuygulama.R;

public class GirisActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giris);

        new Bekle().start();

        setTitle("");
    }

    private class Bekle extends Thread
    {
        @Override
        public void run()
        {
            super.run();

            try {
                Thread.sleep(2000);
            }catch (Exception e)
            { }

            Intent in = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(in);
            finish();
        }
    }


}
