package com.ismek.ogrenci.satisuygulama.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ismek.ogrenci.satisuygulama.R;

public class UrunDetayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urun_detay);
    }
}
