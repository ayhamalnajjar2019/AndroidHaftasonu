package com.ismek.ogrenci.satisuygulama.Model;

public class AltKategori {
    private int id;
    private int ustkategoriId;
    private String kategoriAdi;
    private String kategoriResim;
    private String kategoriAciklama;

    public AltKategori() {
    }

    public AltKategori(int id, int ustkategoriId, String kategoriAdi, String kategoriResim, String kategoriAciklama) {
        this.id = id;
        this.ustkategoriId = ustkategoriId;
        this.kategoriAdi = kategoriAdi;
        this.kategoriResim = kategoriResim;
        this.kategoriAciklama = kategoriAciklama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUstkategoriId() {
        return ustkategoriId;
    }

    public void setUstkategoriId(int ustkategoriId) {
        this.ustkategoriId = ustkategoriId;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getKategoriResim() {
        return kategoriResim;
    }

    public void setKategoriResim(String kategoriResim) {
        this.kategoriResim = kategoriResim;
    }

    public String getKategoriAciklama() {
        return kategoriAciklama;
    }

    public void setKategoriAciklama(String kategoriAciklama) {
        this.kategoriAciklama = kategoriAciklama;
    }
}
