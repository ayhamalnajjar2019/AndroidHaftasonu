package com.ismek.ogrenci.satisuygulama.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ismek.ogrenci.satisuygulama.Model.AltKategori;
import com.ismek.ogrenci.satisuygulama.R;

import java.util.ArrayList;

public class AdpterAltKategori extends BaseAdapter
{
    private ArrayList<AltKategori> Altkat;
    private Context context;
    private LayoutInflater layoutInflater;

    @Override
    public int getCount() {
        return Altkat.size();
    }

    @Override
    public AltKategori getItem(int position) {
        return Altkat.get(position);

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.list_kategori, null);

        ImageView img = v.findViewById(R.id.imAltKategori);
        TextView TvBig = v.findViewById(R.id.TvBig);
        TextView Tvsmall= v.findViewById(R.id.TvSmall);
        TvBig.setText(Altkat.get(position).getKategoriAdi());
        Tvsmall.setText(Altkat.get(position).getKategoriAciklama());
        Glide.with(context)
                .load(Altkat.get(position).getKategoriResim())
                .into(img);

        return v;
    }
}
