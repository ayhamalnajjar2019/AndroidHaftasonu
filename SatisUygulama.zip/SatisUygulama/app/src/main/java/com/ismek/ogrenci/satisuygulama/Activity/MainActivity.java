package com.ismek.ogrenci.satisuygulama.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.GridView;

import com.ismek.ogrenci.satisuygulama.Adapter.CKategoriAdaptor;
import com.ismek.ogrenci.satisuygulama.Model.CKategori;
import com.ismek.ogrenci.satisuygulama.R;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    GridView grid;
    CKategoriAdaptor adaptor;
    ArrayList<CKategori> liste = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        liste.add( new CKategori(1,"Bilgisayar", "https://icdn.ensonhaber.com/resimler/galeri/1_4813.jpg") );
        liste.add( new CKategori(2,"Teknoloji", "https://icdn.ensonhaber.com/resimler/galeri/3_4460.jpg") );
        liste.add( new CKategori(3,"Giyim", "https://icdn.ensonhaber.com/resimler/galeri/4_4376.jpg") );
        liste.add( new CKategori(4,"Beyaz Eşya", "https://icdn.ensonhaber.com/resimler/galeri/5_4186.jpg") );
        liste.add( new CKategori(5,"Telefon", "https://icdn.ensonhaber.com/resimler/galeri/6_3916.jpg") );
        liste.add( new CKategori(6,"Mobilya", "https://icdn.ensonhaber.com/resimler/galeri/7_3718.jpg") );
        liste.add( new CKategori(7,"Spor", "https://icdn.ensonhaber.com/resimler/galeri/8_3492.jpg") );
        liste.add( new CKategori(8,"Çocuk", "https://icdn.ensonhaber.com/resimler/galeri/11_2734.jpg") );
        liste.add( new CKategori(9,"Sanat", "https://icdn.ensonhaber.com/resimler/galeri/13_2214.jpg") );
        liste.add( new CKategori(10,"Kitap", "https://icdn.ensonhaber.com/resimler/galeri/14_2047.jpg") );
        liste.add( new CKategori(11,"Yazılım", "https://icdn.ensonhaber.com/resimler/galeri/15_1888.jpg") );
        liste.add( new CKategori(12,"Müzik", "https://icdn.ensonhaber.com/resimler/galeri/16_1714.jpg") );
        liste.add( new CKategori(13,"Otomotiv", "https://icdn.ensonhaber.com/resimler/galeri/17_1594.jpg") );
        liste.add( new CKategori(14,"Hobi", "https://icdn.ensonhaber.com/resimler/galeri/18_1512.jpg") );
        liste.add( new CKategori(15,"Kırtasiye", "https://icdn.ensonhaber.com/resimler/galeri/22_1051.jpg") );


        adaptor = new CKategoriAdaptor(liste, getApplicationContext());

        grid = findViewById(R.id.AnaKategoriGrid);
        grid.setAdapter(adaptor);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),AltActivity.class);
                intent.putExtra("Kategori", (Serializable) liste.get(position));
                startActivity(intent);
            }
        });

    }
}
