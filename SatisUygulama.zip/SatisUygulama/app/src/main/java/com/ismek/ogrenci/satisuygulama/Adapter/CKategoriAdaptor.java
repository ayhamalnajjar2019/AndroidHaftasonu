package com.ismek.ogrenci.satisuygulama.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ismek.ogrenci.satisuygulama.Model.CKategori;
import com.ismek.ogrenci.satisuygulama.R;

import java.util.ArrayList;

public class CKategoriAdaptor extends BaseAdapter
{
    private ArrayList<CKategori> Liste;
    private Context Konteks;
    private LayoutInflater LayInf;

    public CKategoriAdaptor()
    {
    }

    public CKategoriAdaptor(ArrayList<CKategori> liste, Context konteks)
    {
        Liste = liste;
        Konteks = konteks;
        LayInf = (LayoutInflater) konteks.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return Liste.size();
    }

    @Override
    public CKategori getItem(int position) {
        return Liste.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View v = LayInf.inflate(R.layout.liste_satir_kategori, null);

        ImageView img = v.findViewById(R.id.lsKategoriResim);
        TextView tx = v.findViewById(R.id.lsKategoriBaslik);

        tx.setText(Liste.get(position).Baslik);

        Glide.with(Konteks)
                .load(Liste.get(position).Resim)
                .into(img);

        return v;
    }
}
