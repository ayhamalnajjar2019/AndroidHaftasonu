package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterKategori;
import com.serifgungor.satisuygulamasi.Model.Kategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView kategoriler;
    AdapterKategori adapterKategori;
    ArrayList<Kategori> kat = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kategoriler = findViewById(R.id.gridViewKategoriler);

        //int id, String ad, String resim
        kat.add(new Kategori(1,"Bilgisayar","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/LENOVO/thumb/v2-87462_medium.JPG"));
        kat.add(new Kategori(2,"Giyim","https://img-divarese.mncdn.com/productimages/2400403714272_1_450_692.jpg"));
        kat.add(new Kategori(3,"Beyaz Eşya","https://www.arcelik.com.tr/content/dam/arcelik-tr/arcelikTurkeyProductCatalog/commerce/global/5374-Beyaz-Esya/5384-Camasir-Makinesi/7150620100-8123-CMKB/7150620100-8123-CMKB-5384-Camasir-Makinesi-7150620100-LO1-20170315-132015.png.transform/rendition-480/image.png"));
        kat.add(new Kategori(4,"Mobilya","https://image.evidea.com/ProductImage/2018_09/SGX680/evidea-mobilya-SGX680-4_1.jpg"));

        adapterKategori = new AdapterKategori(kat,getApplicationContext());
        kategoriler.setAdapter(adapterKategori);


        kategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                Intent intent = new Intent(getApplicationContext(),AltKategoriActivity.class);
                intent.putExtra("kategori",kat.get(position));
                startActivity(intent);

            }
        });

    }
}
