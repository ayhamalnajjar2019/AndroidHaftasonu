package com.example.lab08.buttonmach;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecoundActivity extends AppCompatActivity {
TextView Tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secound);
        Tv = findViewById(R.id.Tv);
        String nameSureName = getIntent().getStringExtra("yazi");
        Tv.setText(nameSureName);
    }
}
