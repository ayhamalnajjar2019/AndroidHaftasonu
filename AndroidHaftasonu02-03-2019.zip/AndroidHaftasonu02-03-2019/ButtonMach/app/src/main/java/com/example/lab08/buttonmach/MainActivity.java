package com.example.lab08.buttonmach;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
LinearLayout linearLayout;
    @Override
    public void onClick(View v){
        Button b = (Button)v;
        String yaz= b.getText().toString();
        Intent intent = new Intent(getApplicationContext(),SecoundActivity.class);
        intent.putExtra("yazi",yaz);
        startActivity(intent);
    }
public  void  butonlar (int count)
{
    for ( int i = 0 ; i<count;i++)
    {
        Button btn = new Button(getApplicationContext());
        btn.setText("Button"+i);
        btn.setOnClickListener(this);
        linearLayout.addView(btn);
    }
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        linearLayout =findViewById(R.id.linear);
        butonlar(20);

    }
}
