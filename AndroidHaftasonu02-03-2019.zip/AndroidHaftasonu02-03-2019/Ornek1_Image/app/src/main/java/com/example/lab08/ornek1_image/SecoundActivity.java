package com.example.lab08.ornek1_image;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SecoundActivity extends AppCompatActivity {
    TextView TvTextView;
    ImageView ImgV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secound);
        TvTextView =findViewById(R.id.tvView);
        ImgV =findViewById(R.id.ImgV);
        String ImgName = getIntent().getStringExtra("ImgName");
        TvTextView.setText(ImgName);
        switch (ImgName)
        {
            case "cat":
                ImgV.setImageResource(R.drawable.cat);
                break;
            case "deer":
                ImgV.setImageResource(R.drawable.deer);
                break;
            case "dog":
                ImgV.setImageResource(R.drawable.dog);
                break;
            case "duck":
                ImgV.setImageResource(R.drawable.duck);
                break;
        }
    }
}
