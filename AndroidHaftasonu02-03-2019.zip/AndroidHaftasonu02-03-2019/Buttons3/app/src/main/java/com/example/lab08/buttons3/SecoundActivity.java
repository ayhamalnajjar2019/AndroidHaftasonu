package com.example.lab08.buttons3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecoundActivity extends AppCompatActivity {
    TextView TvTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secound);
        TvTextView =findViewById(R.id.tvButtonName);
        String nameSureName = getIntent().getStringExtra("BtnName");
        TvTextView.setText(nameSureName);
    }
}
