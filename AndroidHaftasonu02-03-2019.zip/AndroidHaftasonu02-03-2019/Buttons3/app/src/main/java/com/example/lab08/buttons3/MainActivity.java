package com.example.lab08.buttons3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button btnMain,btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnMain=findViewById(R.id.btnmain);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,SecoundActivity.class);
                intent.putExtra("BtnName",btnMain.getText().toString());
                startActivity(intent);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,SecoundActivity.class);
                intent.putExtra("BtnName",btn1.getText().toString());
                startActivity(intent);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,SecoundActivity.class);
                intent.putExtra("BtnName",btn2.getText().toString());
                startActivity(intent);
            }
        });
    }
}
