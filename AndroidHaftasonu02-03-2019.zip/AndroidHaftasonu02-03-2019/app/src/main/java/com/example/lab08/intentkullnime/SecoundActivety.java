package com.example.lab08.intentkullnime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecoundActivety extends AppCompatActivity {
TextView TvTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secound);
        TvTextView =findViewById(R.id.tvNameSureName);
        String nameSureName = getIntent().getStringExtra("nameSureName");
        TvTextView.setText(nameSureName);
    }
}
