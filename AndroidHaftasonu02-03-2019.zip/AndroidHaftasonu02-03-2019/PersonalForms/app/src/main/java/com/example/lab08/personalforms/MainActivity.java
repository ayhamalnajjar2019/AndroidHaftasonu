package com.example.lab08.personalforms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText txtFullName,txtUniName,txtClassNum;
Button BtnSend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtFullName=findViewById(R.id.txtfullname);
        txtUniName=findViewById(R.id.txtuniname);
        txtClassNum=findViewById(R.id.txtclassnum );
        BtnSend = findViewById(R.id.btnsend);
        BtnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle =new Bundle();
                bundle.putString("FullName",txtFullName.getText().toString());
                bundle.putString("UniName",txtUniName.getText().toString());
                bundle.putInt("ClassNum",Integer.parseInt(txtClassNum.getText().toString()) );
                /*Intent intent=new Intent(MainActivity.this,SecoundActivity.class);
                intent.putExtra("FullName",txtFullName.getText().toString());
                intent.putExtra("UniName",txtUniName.getText().toString());
                intent.putExtra("ClassNum",txtClassNum.getText().toString());
                startActivity(intent);*/
                Intent intent=new Intent(MainActivity.this,SecoundActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
