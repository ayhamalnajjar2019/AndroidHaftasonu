package com.example.lab08.personalforms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecoundActivity extends AppCompatActivity {
TextView TvFullName,TvUniName,TvClassNum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secound);
        TvFullName=findViewById(R.id.TvFullName);
        TvUniName=findViewById(R.id.TvUniName);
        TvClassNum=findViewById(R.id.TvClassNum);

        Bundle bundle=getIntent().getExtras();
        String FullName=bundle.getString("FullName");
        String UniName=bundle.getString("UniName");
        int ClassNum=bundle.getInt("ClassNum");
        TvFullName.setText(FullName);
        TvUniName.setText(UniName);
        TvClassNum.setText(""+ClassNum);
       /* TvFullName.setText( getIntent().getStringExtra("FullName"));
        TvUniName.setText( getIntent().getStringExtra("UniName"));
        TvClassNum.setText( getIntent().getStringExtra("ClassNum"));*/
    }
}
