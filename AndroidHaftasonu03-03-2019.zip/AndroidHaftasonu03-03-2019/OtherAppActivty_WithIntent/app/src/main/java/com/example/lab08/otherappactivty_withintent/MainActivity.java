package com.example.lab08.otherappactivty_withintent;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button btnCall,btnGo,btnSend,btnMarketSearch,btnLocation,btnMailSend;
EditText etPhoneNumber,etWebSit,etMessText,etMessNum,etEmail,etTitle,etContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCall=findViewById(R.id.btnCall);
        btnGo=findViewById(R.id.btnGo);
        btnSend=findViewById(R.id.btnSend);
        btnSend=findViewById(R.id.btnSend);
        etPhoneNumber=findViewById(R.id.etNumberPhone);
        etWebSit=findViewById(R.id.etWebSit);
        etMessText=findViewById(R.id.etMess);
        btnMarketSearch=findViewById(R.id.btnMarketSearch);
        btnLocation=findViewById(R.id.btnLocation);
        btnMailSend=findViewById(R.id.btnSendMail);

        etEmail=findViewById(R.id.etEmail);
        etTitle=findViewById(R.id.etTitle);
        etContent=findViewById(R.id.etContent);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri=Uri.parse("tel:"+etPhoneNumber.getText().toString()) ;
                i.setData(uri);
                startActivity(i);
            }
        });
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri=Uri.parse("http://"+etWebSit.getText().toString()) ;
                i.setData(uri);
                startActivity(i);
            }
        });
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SENDTO);
                Uri uri=Uri.parse("sms:"+etMessNum.getText().toString()) ;
                i.setData(uri);
                i.putExtra("sms_body",etMessText.getText().toString());
                startActivity(i);
            }
        });
        btnMarketSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("market://details?id=com.Whatsapp"));
                    startActivity(intent);
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(), "Google play store app not found!", Toast.LENGTH_SHORT).show();
                }

            }
        });
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("geo:0.0?q=41.0085812,28.9802257(Ayasofya)")));

            }
        });
        btnMailSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/html");
                    intent.putExtra(Intent.EXTRA_EMAIL,etEmail.getText().toString());
                    intent.putExtra(Intent.EXTRA_SUBJECT,etTitle.getText().toString());
                    intent.putExtra(Intent.EXTRA_TEXT,etContent.getText().toString());
                    startActivity(Intent.createChooser(intent,"choose app"));
                }
                catch (Exception e)
                {

                }


            }
        });
    }
}
