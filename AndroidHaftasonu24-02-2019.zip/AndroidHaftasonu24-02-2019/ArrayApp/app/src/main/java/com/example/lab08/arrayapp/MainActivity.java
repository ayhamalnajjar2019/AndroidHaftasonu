package com.example.lab08.arrayapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    Button BtnClick;
    String [] arr ={"Istanbul","Parise","Tokyo","Londo"};
    int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.TxtCity);
        BtnClick=findViewById(R.id.Btnclick);
        BtnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count==3)
                    count=0;
                else
                    count++;
              textView.setText(""+arr[count]);
            }
        });
    }
}
