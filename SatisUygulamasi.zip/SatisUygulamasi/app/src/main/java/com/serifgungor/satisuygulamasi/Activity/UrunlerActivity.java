package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterUrun;
import com.serifgungor.satisuygulamasi.Helper.DatabaseHelper;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class UrunlerActivity extends AppCompatActivity {

    ArrayList<Urun> urunler = new ArrayList<>();
    AdapterUrun adapterUrun;
    GridView gridView;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Cursor c;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunler);

        AltKategori altKategori =
                (AltKategori)getIntent().getSerializableExtra("altKategori");

        this.setTitle(altKategori.getKategoriAdi() + " Ürünleri");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        gridView = findViewById(R.id.gridViewUrunler);

        //int id, int altKategoriId, String baslik, double fiyat, String resim, String aciklama
        try{
            dbHelper = new DatabaseHelper(getApplicationContext());
            dbHelper.createDatabase();
            db = dbHelper.getReadableDatabase();
            id =altKategori.getId();
            c = db.rawQuery("SELECT * FROM Urun WHERE altKategoriId = "+id+" order by id",null);
            while(c.moveToNext()){
                urunler.add(new Urun(
                        c.getInt(c.getColumnIndex("id")) ,
                        c.getInt(c.getColumnIndex("altKategoriId")),
                        c.getString(c.getColumnIndex("baslik")),
                        c.getDouble(c.getColumnIndex("fiyat")),
                        c.getString(c.getColumnIndex("resim")),
                        c.getString(c.getColumnIndex("aciklama"))));
            }

        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }
      /*  if(altKategori.getId()==1){ //Masaüstü

            urunler.add(new Urun(1,1,"Asus Masaüstü PC",2495,"https://n11scdn1.akamaized.net/a1/1024/elektronik/masaustu-bilgisayar/intel-i7-8gb-ram-1tb-hdd-4gb-ekkarti-215-masaustu-bilgisayar__0953855988187256.jpg","Açıklama kısmı"));
            urunler.add(new Urun(2,1,"Casper Masaüstü PC",1499,"https://n11scdn3.akamaized.net/a1/1024/elektronik/masaustu-bilgisayar/casper-n1c3060-4l05e-intel-celeron3060-4gb-ram-500gb-hdd-desktop__0694907528933088.jpg","Açıklama kısmı"));
            urunler.add(new Urun(3,1,"Lenovo AllInOne PC",3575,"https://www.lenovo.com/medias/lenovo-desktops-ideacentre-brand.png?context=bWFzdGVyfHJvb3R8NzMyMDJ8aW1hZ2UvcG5nfGg2Ny9oZmIvOTM3NDMyMTIxMzQ3MC5wbmd8YzkxODcyMzUzZWE1MTM2Y2NhN2Q1MTg3MDg3NDU2NmVhYTE0MzEyYTI3OTkyNGRkMGQwYjkxY2ZjNGRkMGFlYg&w=1920","Açıklama kısmı"));
            urunler.add(new Urun(4,1,"HP AllInOne PC",6750,"https://cdn.akakce.com/hp/hp-22-b304nt-2bv19ea-all-in-one-pc-z.jpg","Açıklama kısmı"));

        }else if(altKategori.getId()==2){ //Dizüstü

            urunler.add(new Urun(1,2,"Asus Masaüstü PC",2495,"https://n11scdn1.akamaized.net/a1/1024/elektronik/masaustu-bilgisayar/intel-i7-8gb-ram-1tb-hdd-4gb-ekkarti-215-masaustu-bilgisayar__0953855988187256.jpg","Açıklama kısmı"));
            urunler.add(new Urun(2,2,"Casper Masaüstü PC",1499,"https://n11scdn3.akamaized.net/a1/1024/elektronik/masaustu-bilgisayar/casper-n1c3060-4l05e-intel-celeron3060-4gb-ram-500gb-hdd-desktop__0694907528933088.jpg","Açıklama kısmı"));
            urunler.add(new Urun(3,2,"Lenovo AllInOne PC",3575,"https://www.lenovo.com/medias/lenovo-desktops-ideacentre-brand.png?context=bWFzdGVyfHJvb3R8NzMyMDJ8aW1hZ2UvcG5nfGg2Ny9oZmIvOTM3NDMyMTIxMzQ3MC5wbmd8YzkxODcyMzUzZWE1MTM2Y2NhN2Q1MTg3MDg3NDU2NmVhYTE0MzEyYTI3OTkyNGRkMGQwYjkxY2ZjNGRkMGFlYg&w=1920","Açıklama kısmı"));
            urunler.add(new Urun(4,2,"HP AllInOne PC",6750,"https://cdn.akakce.com/hp/hp-22-b304nt-2bv19ea-all-in-one-pc-z.jpg","Açıklama kısmı"));


        }*/



        adapterUrun = new AdapterUrun(urunler,getApplicationContext());
        gridView.setAdapter(adapterUrun);


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(),UrunDetayActivity.class);
                intent.putExtra("urun",urunler.get(position));
                startActivity(intent);

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
