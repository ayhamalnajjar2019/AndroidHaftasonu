package com.example.lab08.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.mp3playerapp.R;

public class SarkilarActivity extends AppCompatActivity {
    ListView Lst_Sarkilar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sarkilar);
        Lst_Sarkilar = findViewById(R.id.Lst_Sarkilar);
    }
}
