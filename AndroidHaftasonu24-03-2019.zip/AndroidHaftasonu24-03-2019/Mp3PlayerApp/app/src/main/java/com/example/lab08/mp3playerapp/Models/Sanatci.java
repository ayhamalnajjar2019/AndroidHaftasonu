package com.example.lab08.mp3playerapp.Models;

public class Sanatci {
    int SanatciId;
   int kategoriId;
   String SanatciAdSoyad;
   String SanatciDogum;
   String SanatciDil;
   String SanatciUlke;
   String SanatciAciklama;
   String SanatciRasim;
    public Sanatci() {
    }

    public Sanatci(int sanatciId, int kategoriId, String sanatciAdSoyad, String sanatciDogum, String sanatciDil, String sanatciUlke, String sanatciAciklama, String sanatciRasim) {
        SanatciId = sanatciId;
        this.kategoriId = kategoriId;
        SanatciAdSoyad = sanatciAdSoyad;
        SanatciDogum = sanatciDogum;
        SanatciDil = sanatciDil;
        SanatciUlke = sanatciUlke;
        SanatciAciklama = sanatciAciklama;
        SanatciRasim = sanatciRasim;
    }

    public int getSanatciId() {
        return SanatciId;
    }

    public void setSanatciId(int sanatciId) {
        SanatciId = sanatciId;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getSanatciAdSoyad() {
        return SanatciAdSoyad;
    }

    public void setSanatciAdSoyad(String sanatciAdSoyad) {
        SanatciAdSoyad = sanatciAdSoyad;
    }

    public String getSanatciDogum() {
        return SanatciDogum;
    }

    public void setSanatciDogum(String sanatciDogum) {
        SanatciDogum = sanatciDogum;
    }

    public String getSanatciDil() {
        return SanatciDil;
    }

    public void setSanatciDil(String sanatciDil) {
        SanatciDil = sanatciDil;
    }

    public String getSanatciUlke() {
        return SanatciUlke;
    }

    public void setSanatciUlke(String sanatciUlke) {
        SanatciUlke = sanatciUlke;
    }

    public String getSanatciAciklama() {
        return SanatciAciklama;
    }

    public void setSanatciAciklama(String sanatciAciklama) {
        SanatciAciklama = sanatciAciklama;
    }

    public String getSanatciRasim() {
        return SanatciRasim;
    }

    public void setSanatciRasim(String sanatciRasim) {
        SanatciRasim = sanatciRasim;
    }
}
