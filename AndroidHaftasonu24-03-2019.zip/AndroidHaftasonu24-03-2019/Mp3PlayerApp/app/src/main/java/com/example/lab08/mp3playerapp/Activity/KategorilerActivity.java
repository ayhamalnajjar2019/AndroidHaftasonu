package com.example.lab08.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.mp3playerapp.Adapter.AdapterMusikKategori;
import com.example.lab08.mp3playerapp.Models.MusikKategori;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class KategorilerActivity extends AppCompatActivity {
    ListView Lst_Kategoriler;
    ArrayList<MusikKategori> Kategoriler;
    AdapterMusikKategori adapterMusikKategori;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategoriler);
        Lst_Kategoriler = findViewById(R.id.Lst_Kategoriler);
        Kategoriler = new ArrayList<>();
    }
}
