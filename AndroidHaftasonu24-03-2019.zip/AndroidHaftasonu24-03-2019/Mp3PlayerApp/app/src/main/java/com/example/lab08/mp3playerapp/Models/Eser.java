package com.example.lab08.mp3playerapp.Models;

public class Eser {
    int eserId;
    int albumId;
    int sanatciId;
    String eserAdi;
    String eserAciklama;
    String yayinYili;
    String eserGorseli;
    String mp3DosyaAdresi;

    public Eser() {
    }

    public Eser(int eserId, int albumId, int sanatciId, String eserAdi, String eserAciklama, String yayinYili, String eserGorseli, String mp3DosyaAdresi) {
        this.eserId = eserId;
        this.albumId = albumId;
        this.sanatciId = sanatciId;
        this.eserAdi = eserAdi;
        this.eserAciklama = eserAciklama;
        this.yayinYili = yayinYili;
        this.eserGorseli = eserGorseli;
        this.mp3DosyaAdresi = mp3DosyaAdresi;

    }

    public int getEserId() {
        return eserId;
    }

    public void setEserId(int eserId) {
        this.eserId = eserId;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public int getSanatciId() {
        return sanatciId;
    }

    public void setSanatciId(int sanatciId) {
        this.sanatciId = sanatciId;
    }

    public String getEserAdi() {
        return eserAdi;
    }

    public void setEserAdi(String eserAdi) {
        this.eserAdi = eserAdi;
    }

    public String getEserAciklama() {
        return eserAciklama;
    }

    public void setEserAciklama(String eserAciklama) {
        this.eserAciklama = eserAciklama;
    }

    public String getYayinYili() {
        return yayinYili;
    }

    public void setYayinYili(String yayinYili) {
        this.yayinYili = yayinYili;
    }

    public String getEserGorseli() {
        return eserGorseli;
    }

    public void setEserGorseli(String eserGorseli) {
        this.eserGorseli = eserGorseli;
    }

    public String getMp3DosyaAdresi() {
        return mp3DosyaAdresi;
    }

    public void setMp3DosyaAdresi(String mp3DosyaAdresi) {
        this.mp3DosyaAdresi = mp3DosyaAdresi;
    }
}
