package com.example.lab08.mp3playerapp.Models;

public class MusikKategori {
    int kategoriId;
    String kategoriAdi;
    String kategoriRasim;

    public MusikKategori() {
    }

    public MusikKategori(int kategoriId, String kategoriAdi, String kategoriRasim) {
        this.kategoriId = kategoriId;
        this.kategoriAdi = kategoriAdi;
        this.kategoriRasim = kategoriRasim;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getKategoriRasim() {
        return kategoriRasim;
    }

    public void setKategoriRasim(String kategoriRasim) {
        this.kategoriRasim = kategoriRasim;
    }
}
