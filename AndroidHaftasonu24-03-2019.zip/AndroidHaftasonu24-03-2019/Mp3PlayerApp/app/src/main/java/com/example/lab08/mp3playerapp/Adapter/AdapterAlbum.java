package com.example.lab08.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lab08.mp3playerapp.Models.Album;
import com.example.lab08.mp3playerapp.Models.MusikKategori;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterAlbum extends BaseAdapter {
    private ArrayList<Album> Albumlar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterAlbum() {
    }

    public AdapterAlbum(ArrayList<Album> albumlar, Context context, LayoutInflater layoutInflater) {
        Albumlar = albumlar;
        this.context = context;
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return Albumlar.size();
    }

    @Override
    public Object getItem(int position) {
        return Albumlar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.album_satirgoruntusu,null);

        TextView tvAlbumAdi,tvAlbumCikisTarihi,tvAlbumAciklama;
        tvAlbumAciklama = v.findViewById(R.id.tvAlbumAciklama);
        tvAlbumCikisTarihi = v.findViewById(R.id.tvAlbumCikisTarihi);
        tvAlbumAdi = v.findViewById(R.id.tvAlbumAdi);

        tvAlbumAdi.setText(Albumlar.get(position).getAlbumAdi());
        tvAlbumAciklama.setText(Albumlar.get(position).getAlbumAciklama());
        tvAlbumCikisTarihi.setText(Albumlar.get(position).getCikisTarihi());

        return v;
    }
}
