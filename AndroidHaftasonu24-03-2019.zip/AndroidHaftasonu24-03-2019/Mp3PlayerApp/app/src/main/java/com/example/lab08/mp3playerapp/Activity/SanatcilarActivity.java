package com.example.lab08.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;

import com.example.lab08.mp3playerapp.Adapter.AdapterMusikKategori;
import com.example.lab08.mp3playerapp.Adapter.AdapterSanatci;
import com.example.lab08.mp3playerapp.Models.MusikKategori;
import com.example.lab08.mp3playerapp.Models.Sanatci;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class SanatcilarActivity extends AppCompatActivity {
    GridView Grid_Sanatci;
    ArrayList<Sanatci> Sanatciler;
    AdapterSanatci adapterSanatci;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sanatcilar);
        Grid_Sanatci = findViewById(R.id.Grid_Santaci);
        Sanatciler = new ArrayList<>();
    }
}
