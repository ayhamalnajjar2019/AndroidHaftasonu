package com.example.lab08.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.mp3playerapp.Models.Album;
import com.example.lab08.mp3playerapp.Models.Eser;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterEser extends BaseAdapter {
    private ArrayList<Eser> Eserler;
    private Context context;
    private LayoutInflater layoutInflater;
    @Override
    public int getCount() {
        return Eserler.size();
    }

    @Override
    public Object getItem(int position) {
        return Eserler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.eser_satirgoruntusu,null);
        ImageView ivEserResim;

        TextView tvEserBaslik,tvEserYayinYili,tvEserAciklama;
        ivEserResim = v.findViewById(R.id.ivEserResim);
        tvEserBaslik = v.findViewById(R.id.tvEserBaslik);
        tvEserYayinYili = v.findViewById(R.id.tvEserYayinYili);
        tvEserAciklama = v.findViewById(R.id.tvEserAciklama);

        Glide
                .with(context)
                .load(Eserler.get(position).getEserGorseli())
                .into(ivEserResim);
        tvEserBaslik.setText(Eserler.get(position).getEserAdi());
        tvEserYayinYili.setText(Eserler.get(position).getYayinYili());
        tvEserAciklama.setText(""+Eserler.get(position).getEserAciklama());
        return v;
    }
}
