package com.example.lab08.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.mp3playerapp.Models.MusikKategori;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterMusikKategori extends BaseAdapter{
    private ArrayList<MusikKategori> kategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterMusikKategori() {
    }

    public AdapterMusikKategori(ArrayList<MusikKategori> kategoriler, Context context, LayoutInflater layoutInflater) {
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Object getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.eser_satirgoruntusu,null);
        ImageView ivKategoriResim;
        TextView tvKategoriBaslik;

        ivKategoriResim = v.findViewById(R.id.ivKategoriResim);
        tvKategoriBaslik = v.findViewById(R.id.tvKategoriBaslik);

        Glide
                .with(context)
                .load(kategoriler.get(position).getKategoriRasim())
                .into(ivKategoriResim);
        tvKategoriBaslik.setText(kategoriler.get(position).getKategoriAdi());
        return v;
    }
}
