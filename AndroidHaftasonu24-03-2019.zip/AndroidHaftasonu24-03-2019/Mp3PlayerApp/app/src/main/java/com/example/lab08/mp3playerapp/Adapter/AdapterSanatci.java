package com.example.lab08.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.mp3playerapp.Models.Eser;
import com.example.lab08.mp3playerapp.Models.Sanatci;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterSanatci extends BaseAdapter {
    private ArrayList<Sanatci> Sanatciler;
    private Context context;
    private LayoutInflater layoutInflater;
    @Override
    public int getCount() {
        return Sanatciler.size();
    }

    @Override
    public Object getItem(int position) {
        return Sanatciler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.sanatci_satirgoruntusu,null);

        ImageView ivSanatciResim;
        TextView tvSanatciAdSoyad,tvSanatciDogumYili;

        ivSanatciResim = v.findViewById(R.id.ivSanatciResim);
        tvSanatciAdSoyad = v.findViewById(R.id.tvSanatciAdSoyad);
        tvSanatciDogumYili = v.findViewById(R.id.tvSanatciDogumYili);

        Glide
                .with(context)
                .load(Sanatciler.get(position).getSanatciRasim())
                .into(ivSanatciResim);

        tvSanatciAdSoyad.setText(Sanatciler.get(position).getSanatciAdSoyad());
        tvSanatciDogumYili.setText(Integer.toString(Integer.parseInt(Sanatciler.get(position).getSanatciDogum())));

        return v;
    }
}
