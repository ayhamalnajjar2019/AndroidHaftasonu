package com.example.lab08.mp3playerapp.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lab08.mp3playerapp.R;

public class AcilisActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().hide();

        new Bekle().start();
    }
    private class Bekle extends Thread{
        @Override
        public void run() {
            super.run();
            try {
                Thread.sleep(2000);
            }catch (Exception e){}

            Intent intent = new Intent(AcilisActivity.this,KategorilerActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
