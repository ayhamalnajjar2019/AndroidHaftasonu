package com.example.lab08.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.mp3playerapp.Adapter.AdapterAlbum;
import com.example.lab08.mp3playerapp.Models.Album;
import com.example.lab08.mp3playerapp.R;

import java.util.ArrayList;

public class AlbumActivity extends AppCompatActivity {
    ListView Lst_Album;
    ArrayList<Album> Albumler;
    AdapterAlbum adapterAlbum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);
        Lst_Album = findViewById(R.id.Lst_Album);
        Albumler = new ArrayList<>();
    }
}
