package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterAltKategori;
import com.serifgungor.satisuygulamasi.Helper.DatabaseHelper;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Kategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {

    ListView altKategori;
    ArrayList<AltKategori> altKategoriler;
    AdapterAltKategori adapterAltKategori;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Cursor c;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);


        /*
        Bir önceki sayfadan doğrudan bir nesneyi, ikinci sayfamıza taşımak istiyorsak
        gönderdiğimiz object'in serializable türünde olması gerekmektedir.
         */
        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());
        // Toolbar'a geri butonu eklenir.
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        altKategori = findViewById(R.id.listViewAltKategoriler);
        altKategoriler = new ArrayList<>();

        /*
        kat.add(new Kategori(1,"Bilgisayar",""));
        kat.add(new Kategori(2,"Giyim",""));
        kat.add(new Kategori(3,"Beyaz Eşya",""));
        kat.add(new Kategori(4,"Mobilya",""));
         */
        try{
            dbHelper = new DatabaseHelper(getApplicationContext());
            dbHelper.createDatabase();
            db = dbHelper.getReadableDatabase();
            id =kategori.getId();
            c = db.rawQuery("SELECT * FROM AltKategori WHERE ustKategoriId = "+id+" order by id",null);
            while(c.moveToNext()){
                altKategoriler.add(new AltKategori(
                        c.getInt(c.getColumnIndex("id")) ,
                        c.getInt(c.getColumnIndex("ustKategoriId")),
                        c.getString(c.getColumnIndex("kategoriAdi")),
                        c.getString(c.getColumnIndex("kategoriResim")),
                        c.getString(c.getColumnIndex("kategoriAciklama"))));
            }

        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }
        /*if(kategori.getId()==1){
            //int id, int ustKategoriId, String kategoriAdi, String kategoriResim, String kategoriAciklama
            altKategoriler.add(new AltKategori(1,1,"Masaüstü Bilgisayar","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/CASPER/thumb/v2-81276-1_medium.jpg","Masaüstü bilgisayar parçaları burada"));
            altKategoriler.add(new AltKategori(2,1,"Dizüstü Bilgisayar","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HOMETECH/thumb/v2-86711-2_medium.jpg","Dizüstü bilgisayar parçaları burada"));
            altKategoriler.add(new AltKategori(3,1,"Sabit HDD/SDD","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/MSI/thumb/v2-93663_small.jpg","Masaüstü bilgisayar parçaları burada"));

        }else if(kategori.getId()==2){

            altKategoriler.add(new AltKategori(4,2,"T-Shirt","https://filiro.weebly.com/uploads/3/2/0/4/32045483/s551209716128872130_p3_i1_w304.jpeg","Bütçenize uygun T-Shirtler burada"));
            altKategoriler.add(new AltKategori(5,2,"Kazak","https://giyimdukkani.n11magazam.com/keep-out-kazak-3467-203-P-2.jpg","Bütçenize uygun Kazaklar burada"));
            altKategoriler.add(new AltKategori(6,2,"Pantolon","https://giyimdukkani.n11magazam.com/mavi-erkek-kot-pantolon-0020225623-1260-P-ORG.jpg","Bütçenize uygun Pantolonlar burada"));

        }else if(kategori.getId()==3){

            altKategoriler.add(new AltKategori(7,2,"Buzdolabı","https://n11scdn.akamaized.net/a1/450/elektronik/buzdolabi/arcelik-2476-cei-no-frost-buzdolabi-3-yil-garantili__0996691779212682.png","aradığın Buzdolabı burada"));
            altKategoriler.add(new AltKategori(8,2,"Derin Dondurucu","https://cdn.akakce.com/arcelik/arcelik-2052-dy-a-cekmeceli-derin-dondurucu-z.jpg","Derin Dondurucular burada"));
            altKategoriler.add(new AltKategori(9,2,"Fırın","https://productimages.hepsiburada.net/s/20/431/9871092219954.jpg","Fırınlar burada"));

        }else if(kategori.getId()==4){

            altKategoriler.add(new AltKategori(10,2,"Mutfak","https://cdn.ikea.com.tr/kategoriler/mutfaklar-metod-mutfak-dolaplari-PH155237.jpg","Mutfak Dolapları"));
            altKategoriler.add(new AltKategori(11,2,"Oturma Odası","https://www.evarthome.com/img/products/nepal-koltuk1_31.08.2018_37f12a7.jpg","Oturma Odası Takımları"));
            altKategoriler.add(new AltKategori(12,2,"Yatak Odası","https://storage.googleapis.com/mobilya/model/19/m-mobilya-28843-5bd95c406e7a3.jpg","Yatak Odası Takımları"));

        }*/

        adapterAltKategori = new AdapterAltKategori(altKategoriler,getApplicationContext());
        altKategori.setAdapter(adapterAltKategori);

        altKategori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                intent.putExtra("altKategori",altKategoriler.get(position));
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
